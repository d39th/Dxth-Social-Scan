from bs4 import BeautifulSoup

def find_element(source, tag, classname):
    soup = BeautifulSoup(source, "html.parser")
    try:
        if tag == 'span':
            found = soup.find(tag, {"class": classname}).text
        else:
            found = soup.find(tag, class_=classname).text
    except AttributeError:
        found = None
    return found

def span(source, classname):
    return find_element(source, 'span', classname)

def ahead(source, classname):
    return find_element(source, 'a', classname)

def div(source, classname):
    return find_element(source, 'div', classname)

def phead(source, classname):
    return find_element(source, 'p', classname)

def h1(source, classname):
    return find_element(source, 'h1', classname)

def section(source, classname):
    return find_element(source, 'section', classname)

# Beispielaufruf:
# print(phead(html_source, "profile__head-display-name"))
