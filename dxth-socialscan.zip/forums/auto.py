from core import banner, color, symbol, clear, highlight, info_highlight, error_highlight, css
from api.extract import *
import json, sys
from urllib.request import urlopen

class config:
    focmint = "./.db/forums.json"

def get_db():
    with open(config.focmint) as f:
        return json.load(f)

try:
    urlopen
except NameError:
    print(f"{color.redbg}Please use Python version >3.0.{color.reset} {color.bold}Otherwise report issues on the {color.greenbg}official GitHub{color.reset}{color.bold} repo for better support.{color.reset}")
    sys.exit(0)
